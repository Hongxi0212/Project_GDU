# Canvas Components

All UI Components are placed within a [Canvas](UICanvas.md).

* [Canvas](class-Canvas.md)
* [Canvas Scaler](script-CanvasScaler.md)
* [Canvas Group](class-CanvasGroup.md)
* [Canvas Renderer](class-CanvasRenderer.md)
